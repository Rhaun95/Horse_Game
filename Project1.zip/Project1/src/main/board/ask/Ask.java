package main.board.ask;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class AskList{
		String titel;
		String inhalt;
		String writer;
		int num;
		AskList(){
			titel = "����	";
			inhalt = "����";
			writer = "�۾���";
			num = 0;
		}
		AskList(String titel, String inhalt, String writer, int num){
			this.titel = titel;
			this.inhalt = inhalt;
			this.writer = writer;
			this.num = num;
		}	// ���� �ʿ�
		public String getTitel() {
			return titel;
		}
		public void setTitel(String titel) {
			this.titel = titel;
		}
		public String getInhalt() {
			return inhalt;
		}
		public void setInhalt(String inhalt) {
			this.inhalt = inhalt;
		}
		public String getWriter() {
			return writer;
		}
		public void setWriter(String writer) {
			this.writer = writer;
		}
		public int getNum() {
			return num;
		}
		public void setNum(int num) {
			this.num = num;
		}
		public void showList(int index) {
			if(index == 0) {
			System.out.println("��ȣ	"+ titel +"	"+ writer);
			}
			else {
			System.out.println(index +"	"+ titel +"		"+ writer);
			System.out.println("   ����: "+ inhalt);
			}
		}
}

public class Ask {
	String writer = "abc";	//�޾ƿð�
	
	AskList askL = new AskList();
	List<AskList> askList = new ArrayList<>();
	AskDao aDao = new AskDao();
	
	Scanner sc = new Scanner(System.in);
	
	public Ask() {
		for(int i = 0; i<aDao.getAskList().size(); i++) {
		askList.add(aDao.getAskList().get(i));
		}
	}
	
	void save() {
		askList.add(new AskList(getTitel(),getInhalt(), writer, askList.size()));
		aDao.setAskList(askList);
	}
	
	String getTitel() {
		System.out.println("����: ");
		String titel = sc.nextLine();
		return titel;
	}
	String getInhalt(){
		System.out.println("����: ");
		return sc.nextLine();
	}
	String getWriter() {
		System.out.println("�۾���: ");
		return sc.nextLine();
	}
	String getNumber() {
		return Integer.toString(askList.size());
	}
	
	void print() {	
		askList.get(0).showList(0);
		for(int i = askList.size()-1 ; i>0; i--) {
			askList.get(i).showList(i);
		}
		System.out.println();
	}
	void editl() {
		System.out.println("��� �Խù��� �����Ͻðڽ��ϱ�?");
		int z = sc.nextInt();
		sc.nextLine();
		if(z<askList.size()) {	//IOB ����
		askList.get(z).setTitel(getTitel());
		askList.get(z).setInhalt(getInhalt());
		askList.get(z).showList(z);
		System.out.println();
		aDao.setAskList(askList);
		}
		else
		System.out.println("�߸��Է��Ͽ����ϴ�.");
		System.out.println();
	}
	
	void remove() {
		System.out.println("��� �Խù��� �����Ͻðڽ��ϱ�?");
		int z = sc.nextInt();
		if(z<askList.size()) {	//IOB ����
		askList.remove(z);
		aDao.setAskList(askList);
		}
		else
		System.out.println("�߸��Է��Ͽ����ϴ�.");
		System.out.println();
	}
	
	void exit() {
		System.out.println("�������� �̵��մϴ�.");
		System.exit(0);
	}
}
